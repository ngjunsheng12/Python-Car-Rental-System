#Manager
class StaffManager:
    def __init__(self, staff_data_file, car_rates_file):
        self.staff_data_file = staff_data_file
        self.car_rates_file = car_rates_file
        self.transactionDataFile = "transactiondata.txt"

    # Manage Staff
    def generate_staff_id(self):
        staff_data = self.load_staff_data()
        if not staff_data:
            return "S0001"
        else:
            last_id = max(int(userid[1:]) for userid in staff_data.keys())
            new_id = last_id + 1
            return f"S{str(new_id).zfill(4)}"

    def load_staff_data(self):
        staff_data = {}
        try:
            with open(self.staff_data_file, "r") as file:
                for line in file:
                    userid, name, role, password, reg_date = line.strip().split(",")
                    staff_data[userid] = [name, role, password, reg_date]
        except FileNotFoundError:
            pass
        return staff_data

    def save_staff_data(self, staff_data):
        with open(self.staff_data_file, "w") as file:
            for userid, (name, role, password, reg_date) in staff_data.items():
                file.write(f"{userid},{name},{role},{password},{reg_date}\n")

    def display_staff_details(self, userid):
        staff_data = self.load_staff_data()
        if userid in staff_data:
            print("===== Staff Details =====")
            print(f"UserID: {userid}")
            print(f"Name: {staff_data[userid][0]}")
            print(f"Role: {staff_data[userid][1]}")
            print(f"Password: {staff_data[userid][2]}")
            print(f"Registration Date: {staff_data[userid][3]}")
        else:
            print("Staff ID not found.")

    def validateRole(self, message):
        while True:
            user_input = input(message)
            if user_input.isdigit():
                if user_input == "1":
                    return "Manager"
                elif user_input == "2":
                    return "Customer Service Staff"
                elif user_input == "3":
                    return "Car Service Staff"
                else:
                    print("Invalid role!")
            else:
                print("Please enter a valid number.")

    def add_staff(self):
        print("===== Add Staff =====")
        name = input("Enter staff name: ")
        role = self.validateRole("Enter staff role (1. Manager 2. Customer Service Staff 3. Car Service Staff): ")
        password = input("Enter staff password: ")
        reg_date = datetime.datetime.now().strftime("%d-%m-%Y")

        staff_data = self.load_staff_data()
        new_id = self.generate_staff_id()
        staff_data[new_id] = [name, role, password, reg_date]
        self.save_staff_data(staff_data)  # Save data after adding a staff member
        print(f"Staff added successfully with ID: {new_id}")

    def show_staff_data(self):
        try:
            with open(self.staff_data_file, 'r') as file:
                lines = file.readlines()

                print("\n{:^130s}".format("Registered Staff\n"))
                print("{:<30s}{:<20s}{:<30s}{:<20s}{:<20s}".format(
                    "Staff ID", "Name", "Role", "Password", "Registration_date"))
                print("-" * 130)
                for line in lines:
                    details = line.strip().split(',')
                    print("{:<30s}{:<20s}{:<30s}{:<20s}{:<20s}".format(
                        details[0], details[1], details[2], details[3], details[4]))

        except FileNotFoundError:
            print("File not found.")
        except Exception as e:
            print("An error occurred:", e)

    def update_staff(self):
        userid = input("Enter staff ID to update: ")
        staff_data = self.load_staff_data()

        if userid in staff_data:
            name = input("Enter updated name (leave blank to keep current): ")
            role = self.validateRole(
                "Enter staff role (1. Manager 2. Customer Service Staff 3. Car Service Staff): ")
            password = input("Enter updated password (leave blank to keep current): ")

            if name:
                staff_data[userid][0] = name
            if role:
                staff_data[userid][1] = role
            if password:
                staff_data[userid][2] = password

            self.save_staff_data(staff_data)
            print(f"Staff with ID {userid} updated successfully.")
        else:
            print("Staff ID not found.")

    def delete_staff(self, userid):
        self.display_staff_details(userid)
        staff_data = self.load_staff_data()
        if userid in staff_data:
            confirm = input("Are you sure you want to delete this staff? (yes/no): ").lower()
            if confirm == "yes":
                del staff_data[userid]
                self.save_staff_data(staff_data)
                print("Staff deleted successfully.")
            else:
                print("Deletion canceled.")
        else:
            print("Staff ID not found.")

    # Update Rates
    def save_renting_rates(self, rentingRateFile, rates_data):
        with open(rentingRateFile, "w") as file:
            for data in rates_data:
                line = f"{data['update_date']},{data['four_passengers_car']},{data['seven_passengers_car']},{data['nine_passengers_car']}\n"
                file.write(line)

    def updateRentingRate(self):
        update_date = datetime.datetime.now().strftime("%Y-%m-%d")
        four_passengers_car = int(input("Enter rate for 4 seaters: "))
        seven_passengers_car = int(input("Enter rate for 7 seaters: "))
        nine_passengers_car = int(input("Enter rate for 9 seaters: "))

        new_rate_data = {
            "update_date": update_date,
            "four_passengers_car": four_passengers_car,
            "seven_passengers_car": seven_passengers_car,
            "nine_passengers_car": nine_passengers_car
        }

        self.save_renting_rates(self.car_rates_file, [new_rate_data])
        print("Updated Rates successfully.")

    # Monthly Report
    def show_transcaction_data(self):
        try:
            with open(self.transactionDataFile, 'r') as file:
                lines = file.readlines()

                print("\n{:^140s}".format("Transaction Data\n"))
                print("{:<20s}{:<20s}{:<20s}{:<20s}{:<20s}{:<20s}{:<20s}".format(
                    "CarRegNo", "Customer ID", "Rental Date", "Return Date", "Period Days", "Payment Method",
                    "Total Amount(RM)"))
                print("-" * 150)
                for line in lines:
                    details = line.strip().split(',')
                    print("{:<20s}{:<20s}{:<20s}{:<20s}{:<20s}{:<20s}{:<20s}".format(
                        details[0], details[1], details[2], details[3], details[4], details[5], details[6]))

        except FileNotFoundError:
            print("File not found.")
        except Exception as e:
            print("An error occurred:", e)

    def read_transaction_data(self, file_path):
        with open(file_path, 'r') as file:
            data = [line.strip().split(',') for line in file.readlines()]
        return data

    def generate_monthly_report(self, month, year):
        transaction_data = self.read_transaction_data(self.transactionDataFile)
        total_amount = 0
        for transaction in transaction_data:
            rental_date = datetime.datetime.strptime(transaction[2], "%Y-%m-%d")
            if rental_date.month == month and rental_date.year == year:
                total_amount += float(transaction[6])  # Assuming total amount is in index 6
        return total_amount

    def update_own_profile(self):
        userid = input("Enter staff ID to update: ")
        staff_data = self.load_staff_data()

        if userid in staff_data:
            name = input("Enter updated name (leave blank to keep current): ")
            role = self.validateRole(
                "Enter staff role (1. Manager 2. Customer Service Staff 3. Car Service Staff): ")
            password = input("Enter updated password (leave blank to keep current): ")

            if name:
                staff_data[userid][0] = name
            if role:
                staff_data[userid][1] = role
            if password:
                staff_data[userid][2] = password

            self.save_staff_data(staff_data)
            print(f"Staff with ID {userid} updated successfully.")
        else:
            print("Staff ID not found.")


def manage_menu():
    staff_manager = StaffManager("staff_data.txt", "car_rates.txt")
    print("===== Manage Staff =====")
    while True:
        print("1. Add Staff")
        print("2. Update Staff")
        print("3. Delete Staff")
        print("0. Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            staff_manager.add_staff()
        elif choice == "2":
            staff_manager.show_staff_data()
            staff_manager.update_staff()
        elif choice == "3":
            staff_manager.show_staff_data()
            userid = input("Enter staff ID to delete: ")
            staff_manager.delete_staff(userid)
        elif choice == "0":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please enter a valid option.")


# Main Menu For Manager
def manager_menu():
    staff_manager = StaffManager("staff_data.txt", "car_rates.txt")
    print("===== Manager Menu =====")
    while True:
        print("1. Manage Staff")
        print("2. Set Car Rental Rate")
        print("3. View Monthly Report")
        print("4. Update Own Profile")
        print("0. Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            manage_menu()
        elif choice == "2":
            staff_manager.updateRentingRate()
        elif choice == "3":
            staff_manager.show_transcaction_data()
            month = int(input("Please enter the Month you want to view (1-12): "))
            year = int(input("Please enter the Year you want to view: "))
            total_amount = staff_manager.generate_monthly_report(month, year)
            print(f"Total amount for {month}-{year}: {total_amount}")
        elif choice == "4":
            staff_manager.show_staff_data()
            staff_manager.update_own_profile()
        elif choice == "0":
            print("Exiting...")
            break
        else:
            print("Invalid Input")


# CustomerServicesCode
# Final2, Qin Hui, Christen, Jun Sheng, need to add Jun Yuan
import datetime

file_1 = "rentaldata.txt"
file_2 = "car_registry.txt"
file_3 = "transactiondata.txt"
file_4 = "customer_data.txt"
file_5 = "car_rates.txt"
file_6 = "staff_data.txt"


# QinHuis part
def load_customer_data():
    try:
        with open(file_4, "r") as file:
            customers = {}
            for line in file:
                customer_id, customer_data = line.strip().split(":")
                customer_info = customer_data.split(",")
                customers[customer_id] = {
                    "name": customer_info[0],
                    "nric": customer_info[1],
                    "license": customer_info[2],
                    "address": customer_info[3],
                    "phone": customer_info[4],
                    "registration_date": customer_info[5]
                }
            return customers
    except FileNotFoundError:
        return {}


def save_customer_data(customers):
    with open(file_4, "w") as file:
        for customer_id, customer_info in customers.items():
            customer_data = ",".join([
                customer_info["name"],
                customer_info["nric"],
                customer_info["license"],
                customer_info["address"],
                customer_info["phone"],
                customer_info["registration_date"]
            ])
            file.write(f"{customer_id}:{customer_data}\n")


def load_transaction_data():
    try:
        with open(file_3, "r") as file:
            transactions = {}
            for line in file:
                car_reg_no, customer_id, rental_date, return_date, period_date, payment_method, prices = line.strip().split(
                    ",")
                if customer_id not in transactions:
                    transactions[customer_id] = []
                transactions[customer_id].append({
                    "car_reg_no": car_reg_no,
                    "customer_id": customer_id,
                    "rental_date": rental_date,
                    "return_date": return_date,
                    "period_date": period_date,
                    "payment_method": payment_method,
                    "prices": prices
                })
            return transactions
    except FileNotFoundError:
        return {}


def show_transaction_data():
    transactions = load_transaction_data()
    if not transactions:
        print("No transactions found.")
        return

    print("\n{:^100s}".format("Transactions\n"))
    print("{:<15s}{:<15s}{:<15s}{:<15s}{:<15s}{:<20s}{:<15s}".format(
        "Car Reg No", "Customer ID", "Rental Date", "Return Date", "Period", "Payment", "Prices"))
    print("-" * 100)
    for customer_id, customer_transactions in transactions.items():
        for transaction in customer_transactions:
            print("{:<15s}{:<15s}{:<15s}{:<15s}{:<15s}{:<20s}{:<15s}".format(
                transaction["car_reg_no"],
                transaction["customer_id"],
                transaction["rental_date"],
                transaction["return_date"],
                transaction["period_date"],
                transaction["payment_method"],
                transaction["prices"]
            ))


def generate_customer_id(customers):
    if customers:
        last_customer_id = max(customers.keys(), key=lambda x: int(x[1:]))
        new_id = int(last_customer_id[1:]) + 1
    else:
        new_id = 1
    return f"C{new_id:06d}"


def register_customer():
    # load_customer_data() missing 1 required positional argument: 'file_4', I just add the file_4
    customers = load_customer_data(file_4)
    customer_id = generate_customer_id(customers)

    customer_name = input("Enter customer name: ")
    customer_nric = input("Enter customer NRIC (local) or Passport Number (foreigner): ")
    customer_license = input("Enter customer car driving license number: ")
    customer_address = input("Enter customer contact address: ")
    customer_phone = input("Enter customer phone number: ")
    # module 'datetime' has no attribute 'now', I add from datetime import datetime because this file don't have
    customer_registration_date = datetime.datetime.now().strftime("%d-%m-%Y")

    customers[customer_id] = {
        "name": customer_name,
        "nric": customer_nric,
        "license": customer_license,
        "address": customer_address,
        "phone": customer_phone,
        "registration_date": customer_registration_date
    }
    save_customer_data(customers)
    print("Customer registered successfully.")


# Why cannot fnd the file here, try to fix it here.
# The result show I am not sure is here problem or show_customer_data(file_4 ). File not found.
# Enter your Staff ID:
def show_customer_data(file_4):
    try:
        with open(file_4, 'r') as file:
            lines = file.readlines()

            print("\n{:^130s}".format("Registered Customers\n"))
            print("{:<30s}{:<20s}{:<20s}{:<20s}{:<20s}{:<20s}".format(
                "CustomerID & Customer Name", "NRIC", "License", "Address", "Phone", "Registration_date"))
            print("-" * 130)
            for line in lines:
                details = line.strip().split(',')
                print("{:<30s}{:<20s}{:<20s}{:<20s}{:<20s}{:<20s}".format(
                    details[0], details[1], details[2], details[3], details[4], details[5]))

    except FileNotFoundError:
        print("File not found.")
    except Exception as e:
        print("An error occurred:", e)


def update_customer_details():
    customer_id = input("Enter customer ID to update details: ")
    # load_customer_data() missing 1 required positional argument: 'file_4', I add file_4
    customers = load_customer_data(file_4)
    if customer_id in customers:
        print("Enter new details (leave blank to keep existing):")
        customers[customer_id]["name"] = input(f"Customer name [{customers[customer_id]['name']}]: ") or \
                                         customers[customer_id]["name"]
        customers[customer_id]["nric"] = input(
            f"Customer NRIC (local) or Passport Number (foreigner) [{customers[customer_id]['nric']}]: ") or \
                                         customers[customer_id]["nric"]
        customers[customer_id]["license"] = input(
            f"Customer car driving license number [{customers[customer_id]['license']}]: ") or customers[customer_id][
                                                "license"]
        customers[customer_id]["address"] = input(
            f"Customer contact address [{customers[customer_id]['address']}]: ") or customers[customer_id]["address"]
        customers[customer_id]["phone"] = input(f"Customer phone number [{customers[customer_id]['phone']}]: ") or \
                                          customers[customer_id]["phone"]
        save_customer_data(customers)
        print("Customer details updated successfully.")
        show_customer_data(file_4)
    else:
        print("Customer ID not found.")


# junyuan
def load_staff_data_1(file_6):
    staff_data = {}
    try:
        with open(file_6, "r") as file:
            for line in file:
                userid, name, role, password, reg_date = line.strip().split(",")
                staff_data[userid] = [name, role, password, reg_date]
    except FileNotFoundError:
        pass
    return staff_data


# junyuan
def save_staff_data(staff_data):
        with open(file_6, "w") as file:
        # issue is not enough values to unpack (expected 4, got 3)
            for userid, (name, role, password, reg_date) in staff_data.items():
                file.write(f"{userid},{name},{role},{password},{reg_date}\n")


# junyuan
def show_staff_data(file_6):
    try:
        with open(file_6, 'r') as file:
            lines = file.readlines()

            print("\n{:^130s}".format("Registered Staff\n"))
            print("{:<30s}{:<20s}{:<30s}{:<20s}{:<20s}".format(
                "Staff ID", "Name", "Role", "Password", "Registration_date"))
            print("-" * 130)
            for line in lines:
                details = line.strip().split(',')
                print("{:<30s}{:<20s}{:<30s}{:<20s}{:<20s}".format(
                    details[0], details[1], details[2], details[3], details[4]))

    except FileNotFoundError:
        print("File not found.")
    except Exception as e:
        print("An error occurred:", e)


# add on for update_own_profile(file_6) this part role = validateRole to make it run the funtion
def validateRole(prompt):
    role_dict = {
        "1": "Manager",
        "2": "Customer Service Staff",
        "3": "Car Service Staff"
    }

    while True:
        role_choice = input(prompt).strip()
        if role_choice in role_dict:
            return role_dict[role_choice]
        else:
            print("Invalid choice. Please enter a number between 1 and 3.")


# junyuan
def update_own_profile(file_6):
    show_staff_data(file_6)
    userid = input("Enter staff ID to update: ")
    staff_data = load_staff_data_1(file_6)

    if userid in staff_data:
        name = input("Enter updated name (leave blank to keep current): ")
        role = validateRole(
            "Enter staff role (1. Manager 2. Customer Service Staff 3. Car Service Staff): ")
        password = input("Enter updated password (leave blank to keep current): ")

        if name:
            staff_data[userid][0] = name
        if role:
            staff_data[userid][1] = role
        if password:
            staff_data[userid][2] = password

        save_staff_data(staff_data)
        print(f"Staff with ID {userid} updated successfully.")
    else:
        print("Staff ID not found.")


def view_registered_customers():
    show_customer_data(file_4)


def delete_customers_without_transactions():

    customers = load_customer_data(file_4)
    transactions = load_transaction_data()

    customers_to_delete = [customer_id for customer_id in customers if customer_id not in transactions]

    for customer_id in customers_to_delete:
        del customers[customer_id]

    save_customer_data(customers)

    print(f"Deleted {len(customers_to_delete)} customers without transactions.")


def cusmain():
    while True:
        print("\n===== Customer Service System =====")
        print("1. Register Customer")
        print("2. Update Customer Details")
        print("3. View Registered Customers")
        print("4. Update Own Profile")
        print("5. Delete Customers Without Transactions")
        print("6. Next Page to Car Rental Page")
        print("0. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            register_customer()
        elif choice == "2":
            show_customer_data(file_4)
            update_customer_details()
        elif choice == "3":
            view_registered_customers()
        elif choice == "4":
            update_own_profile(file_6)
        elif choice == "5":
            delete_customers_without_transactions()
            show_transaction_data()
        elif choice == "6":
            menu()
        elif choice == "0":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please enter a valid option.")


# Junshengs Part
def load_customer_data(file_4):
    try:
        with open(file_4, "r") as file:
            customers = {}
            for line in file:
                customer_id, customer_data = line.strip().split(":")
                customer_info = customer_data.split(",")
                customers[customer_id] = {
                    "name": customer_info[0],
                    "nric": customer_info[1],
                    "license": customer_info[2],
                    "address": customer_info[3],
                    "phone": customer_info[4],
                    "registration_date": customer_info[5]
                }
            return customers
    except FileNotFoundError:
        return {}


def load_car_data(file_2):
    try:
        with open(file_2, "r") as file:
            cars = {}
            for line in file:
                details = line.strip().split(',')
                car_reg_no = details[0]
                cars[car_reg_no] = {
                    "carManufacturer": details[1],
                    "carModel": details[2],
                    "yearOfManufacturer": details[3],
                    "seatingCapacity": details[4],
                    "lastServiceDate": details[5],
                    "insurancePolicyNumber": details[6],
                    "insuranceExpiryDate": details[7],
                    "roadTaxExpiryDate": details[8],
                    "status": details[9]
                }
            return cars
    except FileNotFoundError:
        return {}
    except IndexError as e:
        print(f"Index error in file {file_2}: {e}")
        return {}
    except Exception as e:
        print(f"An error occurred: {e}")
        return {}


def load_rental_rates(file_5):
    try:
        with open(file_5, "r") as file:
            rates = []
            for line in file:
                parts = line.strip().split(',')  # Splitting by commas
                date_str = parts[0].strip()  # Extracting date string
                try:
                    # type object 'datetime.datetime' has no attribute 'datetime'
                    date = datetime.datetime.strptime(date_str, '%Y-%m-%d')
                    rate_info = {
                        'date': date,
                        '4_seat_rate': float(parts[1]),
                        '7_seat_rate': float(parts[2]),
                        '9_seat_rate': float(parts[3])
                    }
                    rates.append(rate_info)
                except (ValueError, IndexError) as e:
                    print(f"Skipping line with error: {line.strip()} ({e})")
                    continue
            return sorted(rates, key=lambda x: x['date'])
    except FileNotFoundError:
        print(f"File not found: {file_5}")
        return []


def get_latest_rental_rate(seats, rates):
    # Ensure seats is an integer
    try:
        seats = int(seats)
    except ValueError:
        raise ValueError("seats must be an integer or a string that can be converted to an integer")

    latest_rate = rates[-1]  # Get the latest rate based on the sorted order

    if seats <= 4:
        return latest_rate['4_seat_rate']
    elif seats <= 7:
        return latest_rate['7_seat_rate']
    else:
        return latest_rate['9_seat_rate']


def save_data_to_file(file_name, data):
    with open(file_name, "a") as file:
        file.write(data + "\n")


def rentalinformation():
    cars = load_car_data(file_2)
    customers = load_customer_data(file_4)
    rental_rates = load_rental_rates(file_5)

    print("\nHere are the available cars for rental:")
    check_car_record(file_2)

    # I want to show the car is Available,but still got error
    car_reg_no = input("\nEnter car number want to rental: ")
    if car_reg_no not in cars or cars[car_reg_no]["status"] != "Available":
        print("Car not found or already reserved.")
        return

    customer_id = input("Enter your customer ID: ")
    if customer_id not in customers:
        print("Customer not found.")
        return

    rental_date_str = input("Enter rental date (YYYY-MM-DD): ")
    return_date_str = input("Enter return date (YYYY-MM-DD): ")

    try:  # 'str' object cannot be interpreted as an integer
        rental_date = datetime.datetime.strptime(rental_date_str, "%Y-%m-%d")
        return_date = datetime.datetime.strptime(return_date_str, "%Y-%m-%d")
    except ValueError:
        print("Invalid date format.")
        return

    rental_period = (return_date - rental_date).days
    if rental_period <= 0:
        print("Invalid rental period.")
        return

    daily_rate = get_latest_rental_rate(cars[car_reg_no]["seatingCapacity"], rental_rates)
    total_rental = daily_rate * rental_period

    confirmation = input(
        f"Total rental cost is RM {total_rental:.2f} for {rental_period} days. Confirm with these details? (Yes/No): ").strip().lower()

    if confirmation == "yes":
        payment_method = input("Enter payment method (Credit/Debit Card or Touch 'n Go): ")

        rental_data = f"{car_reg_no},{customer_id},{rental_date_str},{return_date_str},{rental_period},Rented"
        transaction_data = f"{car_reg_no},{customer_id},{rental_date_str},{return_date_str},{rental_period},{payment_method},{total_rental:.2f}"

        save_data_to_file(file_1, rental_data)
        save_data_to_file(file_3, transaction_data)

        cars[car_reg_no]["status"] = "Rented"
        customer = customers[customer_id]
        car = cars[car_reg_no]
        car['reg_no'] = car_reg_no
        customer['id'] = customer_id

        print_bill(car, customer, rental_date_str, return_date_str, rental_period, total_rental, payment_method)
        print_receipt(car, customer, rental_date_str, return_date_str, rental_period, total_rental, payment_method)

        print("Transaction completed successfully. This is the receipt.")

    elif confirmation == "no":
        rental_data = f"{car_reg_no},{customer_id},{rental_date_str},{return_date_str},{rental_period},Cancelled"
        save_data_to_file(file_1, rental_data)
        print("Transaction cancelled.")
    else:
        print("Invalid confirmation input. Transaction cancelled.")


def print_bill(car, customer, rental_date_str, return_date_str, rental_period, total_rental, payment_method):
    # print out the bills all the information
    print("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("These are the following bill details for car rental:")
    print(f"Customer ID: {customer['id']}")
    print(f"Customer Name: {customer['name']}")
    print(f"Car Registration Number: {car['reg_no']}")
    print(f"Car Manufacturer: {car['carManufacturer']}")
    print(f"Car Model: {car['carModel']}")
    print(f"Rental Date: {rental_date_str}")
    print(f"Return Date: {return_date_str}")
    print(f"Rental Period: {rental_period} days")
    print(f"Payment Method: {payment_method}")
    print(f"Total Rental Cost: RM {total_rental:.2f}")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")


def print_receipt(car, customer, rental_date_str, return_date_str, rental_period, total_rental, payment_method):
    print(f"""\n
~~~~~~~~~~~~~~~~ Rental Car Payment Receipt ~~~~~~~~~~~~~~~~
| Customer ID                   : {customer['id']}
| Customer Name                 : {customer['name']}
| Car Number Plate              : {car['reg_no']}
| Car Manufacturer              : {car['carManufacturer']}
| Car Rental Date (YYYY/MM/DD)  : {rental_date_str}
| Car Return Date (YYYY/MM/DD)  : {return_date_str}
| Rental Period                 : {rental_period} days
| Car Payment Methods           : {payment_method}
| Total Rental Cost             : RM {total_rental:.2f}
| Confirmation For Payment Successfully.
~~~~~~~~~~~~~~~~ Rental Car Payment Receipt ~~~~~~~~~~~~~~~~
""")


# I think this is no need because just show the check_car_record(file_2) into the rentalinformation()
def check_car_available(file_2):
    print("{:<20s}".format("\nCar Records"))
    try:
        with open(file_2, 'r') as file:
            lines = file.readlines()

            for line in lines:
                details = line.strip().split(',')
                if len(details) >= 10 and details[9] == 'Available':
                    print("\nCar Number Plate:", details[0])
                    print("Manufacturer:", details[1])
                    print("Model:", details[2])
                    print("Year Made:", details[3])
                    print("Capacity:", details[4])
                    print("Status:", details[9])
                    print("\n")
                else:
                    continue

    except FileNotFoundError:
        print("File cannot be found.")
    except Exception as e:
        print("An error occurred:", e)


# Show all the car information details to check
def check_car_record(file_2):
    try:
        with open(file_2, 'r') as file:
            lines = file.readlines()

            print("\n{:^95s}".format("Check Car Registered Records\n"))
            print("{:<25s}{:<15s}{:<15s}{:<15s}{:<15s}{:<10s}".format(
                "Car Registration Number", "Manufacturer", "Model", "Year Made", "Capacity", "Status"))
            print("-" * 100)
            for line in lines:
                details = line.strip().split(',')
                print("{:<25s}{:<15s}{:<15s}{:<15s}{:<15s}{:<10s}".format(
                    details[0], details[1], details[2], details[3], details[4], details[9]))

    except FileNotFoundError:
        print("File not found.")
    except Exception as e:
        print("An error occurred:", e)


# show the list of car rental records to check
def show_car_rental(file_1):
    try:
        with open(file_1, 'r') as file:
            lines = file.readlines()

            print("\n{:^150s}".format("Car Rental Records\n"))
            print("{:<25s}{:<25s}{:<25s}{:<25s}{:<25s}{:<25s}".format(
                "Car Number Plate", "CustomerID", "Rental Date", "Return Date", "Period Days", "Status"))
            print("-" * 140)
            for line in lines:
                details = line.strip().split(',')
                print("{:<25s}{:<25s}{:<25s}{:<25s}{:<25s}{:<25s}".format(
                    details[0], details[1], details[2], details[3], details[4], details[5]))

    except FileNotFoundError:
        print("File not found.")
    except Exception as e:
        print("An error occurred:", e)


# show the list of car rental receipt to check
def show_receipt_transaction(file_3):
    try:
        with open(file_3, 'r') as file:
            lines = file.readlines()

            print("\n{:^175s}".format("Car Rental  Receipt Transaction Records\n"))
            print("{:<25s}{:<25s}{:<25s}{:<25s}{:<25s}{:<25s}{:<25s}".format(
                "Car Number Plate", "CustomerID", "Rental Date", "Return Date", "Period Days", "Payment Method",
                "Prices"))
            print("-" * 160)
            for line in lines:
                details = line.strip().split(',')
                print("{:<25s}{:<25s}{:<25s}{:<25s}{:<25s}{:<25s}{:<25s}".format(
                    details[0], details[1], details[2], details[3], details[4], details[5], details[6]))

    except FileNotFoundError:
        print("File not found.")
    except Exception as e:
        print("An error occurred:", e)


def update_car_status(file_2):
    # Show the current car record before update
    print("\nNow is showing the current car records for the car status before updating with car new status details:")
    check_car_record(file_2)

    try:
        with open(file_2, 'r') as file:
            lines = file.readlines()

        car_reg_to_update = input("\nPlease enter the car number to update the current car rental status: ")
        new_status = input(
            "Please enter the new rental status for car details to update in the car record (e.g. 'Available / Reserved / Rented'): ")

        updated_lines = []
        car_found = False
        for line in lines:
            details = line.strip().split(',')
            if details[0] == car_reg_to_update:
                details[9] = new_status  # Update the status
                car_found = True
            updated_lines.append(','.join(details) + '\n')

        if not car_found:
            print(f"No car found with registration number {car_reg_to_update}.")
        else:
            with open(file_2, 'w') as file:
                file.writelines(updated_lines)

            print("\nCar status has been updated successfully.")
            print("\nNow is showing updated car status records:")
            check_car_record(file_2)

    except FileNotFoundError:
        print("File cannot be found.")
    except Exception as e:
        print("An error occurred:", e)


# delete list rental transactions record
def delete_rental_receipt(file_1):
    # Display all car records before deletion
    print("\nNow showing all the car rental receipts records. Which one do you need to delete?")
    show_car_rental(file_1)

    status_to_delete = input("\nPlease enter the status to delete (e.g., 'Cancelled'): ").strip()

    try:
        with open(file_1, 'r') as file:
            lines = file.readlines()

        with open(file_1, 'w') as file:
            for line in lines:
                if status_to_delete not in line.split(',')[-1].strip():
                    file.write(line)

        print(f"\nCar records with status '{status_to_delete}' have been deleted successfully.")

        # Display all car records again after deletion
        print("\nShowing updated car records:")
        show_car_rental(file_1)

    except FileNotFoundError:
        print(f"File {file_1} not found.")
    except Exception as e:
        print(f"An error occurred: {e}")


# here is the main menu to show all the options
def menu():
    while True:
        print("\n===== Car Rental System =====")
        print("1) For Car Rental")
        print("2) Check Car Registered Record")
        print("3) List out Car Rental")
        print("4) List Out Car Rental Receipt Transactions")
        print("5) Update for Car Registered Rental Status Record")
        print("6) Delete for Cancelled the Car Rental Transactions")
        print("7) Back to Customer Service System")
        print("0) Exit")

        option = int(input("Please enter choose which option (1-7): "))

        if option == 1:
            rentalinformation()

        elif option == 2:
            check_car_record(file_2)
            print("\nhere is the all data for checking car record.")

        elif option == 3:
            show_car_rental(file_1)
            print("\nhere will list out all the car rental given that date.")

        elif option == 4:
            show_receipt_transaction(file_3)
            print("\nhere will list out all the rental receipt transactions given that date.")

        elif option == 5:
            update_car_status(file_2)
            print("\nThis is updated into the car status record file.")

        elif option == 6:
            delete_rental_receipt(file_1)
            print("\nThis is deleted the car record.")

        elif option == 7:
            cusmain()
            print("\nThis is go back to customer service system page.")

        elif option == 0:
            print("Exiting Program From 5.....")
            print("Exiting Program From 4.....")
            print("Exiting Program From 3.....")
            print("Exiting Program From 2.....")
            print("Exiting Program From 1.....")
            print("Exiting Program From 0.....")
            print("Exiting Program BYEBYE")
            break
        else:
            print("Invalid Number. Please try again.")


# Christen Part
def start():
    while True:
        try:
            print("\n===== Car Registration System =====")
            print("1) Register A Car")
            print("2) Update Car Details and Rental Status")
            print("3) View Registered Cars")
            print("4) Update Own Profile")
            print("5) Go Back to Main Menu Page")
            print("0) Exit")

            selection = int(input("Pick an option you would like to do: "))

            if selection == 1:
                register_car()
            elif selection == 2:
                update_car()
            elif selection == 3:
                view_cars()
            elif selection == 4:
                update_own_profile(file_6)
            elif selection == 5:
                choose_menu()
            elif selection == 0:
                print("Exiting...")
                break
            else:
                print("Invalid selection. Please try again.")
        except ValueError:
            print("Please enter a valid number.")


def register_car():
    print("Register a new car")
    car_number = input("Enter Car Registration Number: ")
    car_brand = input("Enter Car Manufacturer: ")
    car_model = input("Enter Car Model: ")
    car_yearofmake = input("Enter The Manufacturing Year Of The Car: ")
    car_capacity = input("Enter The Capacity Of the Car: ")
    car_lastservice = input("Enter The Last Time The Car Was Serviced (YYYY-MM-DD): ")
    car_insuranspolicy = input("Enter Insurance Policy: ")
    car_insuransexpiry = input("Enter The Expiry Date Of the Insurance (YYYY-MM-DD): ")
    car_roadtaxexpiry = input("Enter The Expiry Date Of the RoadTax (YYYY-MM-DD): ")

    car_data = [
        car_number,
        car_brand,
        car_model,
        car_yearofmake,
        car_capacity,
        car_lastservice,
        car_insuranspolicy,
        car_insuransexpiry,
        car_roadtaxexpiry,
        "Available"
    ]

    with open(file_2, 'a') as file:
        file.write(','.join(car_data) + '\n')

    print("Car registration details saved successfully.\n")


def update_car():
    view_cars()

    registration_number = input("Enter Car Registration Number to update: ")

    with open(file_2, 'r') as file:
        lines = file.readlines()

    car_found = False
    updated_lines = []

    for line in lines:
        car_info = line.strip().split(',')
        if car_info[0] == registration_number:
            car_found = True
            print("Car found. Enter new information:")
            car_info[5] = input("New Last Service: ")
            car_info[6] = input("New Insurance Policy: ")
            car_info[7] = input("New Insurance Expiry: ")
            car_info[8] = input("New Road Tax Expiry: ")
            print("Select Rental Action (1 - Reserve, 2 - Rent, 3 - Service, 4 - Dispose): ", end="")
            rental_action = input()
            status_mapping = {'1': 'Reserve', '2': 'Rent', '3': 'Service', '4': 'Dispose'}
            car_info[9] = status_mapping.get(rental_action, car_info[9])
            updated_lines.append(','.join(car_info) + '\n')
        else:
            updated_lines.append(line)

    if car_found:
        with open(file_2, 'w') as file:
            file.writelines(updated_lines)
        print("Car information and Rental Status updated successfully.\n")
    else:
        print("Car not found.")


def view_cars():
    try:
        with open(file_2, 'r') as file:
            lines = file.readlines()

            print("\n{:^170s}".format("Check Car Registered Records\n"))
            print("{:<25s}{:<15s}{:<15s}{:<15s}{:<15s}{:<15s}{:<20s}{:<20s}{:<20s}{:<10s}".format(
                "Car Registration Number", "Manufacturer", "Model", "Year Made", "Capacity", "Last Service",
                "Insurance Policy", "Insurance Expiry", "Road Tax Expiry", "Status"))
            print("-" * 175)
            for line in lines:
                details = line.strip().split(',')
                print("{:<25s}{:<15s}{:<15s}{:<15s}{:<15s}{:<15s}{:<20s}{:<20s}{:<20s}{:<10s}".format(
                    details[0], details[1], details[2], details[3], details[4], details[5], details[6], details[7],
                    details[8], details[9]))

    except FileNotFoundError:
        print("File not found.")
    except Exception as e:
        print("An error occurred:", e)


def choose_menu():
    staff_manager = StaffManager("staff_data.txt", "car_rates.txt")
    print("===== Which Service would you like to choose =====")
    while True:
        print("1) Manager Options")
        print("2) Customer Service Options")
        print("3) Car Registry Options")
        print("4) Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            manager_menu()
        elif choice == "2":
            cusmain()
        elif choice == "3":
            start()
        elif choice == "4":
            break
        else:
            print("Invalid Input")

#manager = choose_menu()
#customer = cusmain()
#car = start()

#login
def load_staff_data(file_6):
    staff_data = {}
    with open(file_6, 'r') as file:
        for line in file:
            parts = line.strip().split(',')
            staff_data[parts[0]] = {'name': parts[1], 'occupation': parts[2], 'password': parts[3]}
    return staff_data


# Login function
def login(staff_data):
    attempts = 3  
    
    while attempts > 0:
        username = input("Please enter your staffid: ").strip()
        
        
        if username in staff_data:
            password = input("Please enter your password: ").strip()
            
            
            if password == staff_data[username]['password']:
                print("Login successful! Welcome {}.".format(username))
                occupation = staff_data[username]['occupation']
                
                if occupation == 'Manager':
                    choose_menu()
                elif occupation == 'Customer Service Staff':
                    cusmain()
                elif occupation == 'Car Service Staff':
                    start()
                else:
                    print("Invalid occupation.")
                break
            else:
                attempts -= 1
                print("Incorrect password. You have {} attempts left.".format(attempts))
        else:
            print("Invalid username. Please try again.")

    if attempts == 0:
        print("You have used all your attempts.")

staff_data = load_staff_data("staff_data.txt")


login(staff_data)